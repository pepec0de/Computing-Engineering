package amc.practica2.clases;

public class TransicionL {
	private int e1, e2;

	public TransicionL(int e1, int e2) {
		super();
		this.e1 = e1;
		this.e2 = e2;
	}

	public int getE1() {
		return e1;
	}

	public int getE2() {
		return e2;
	}
	
	
}
