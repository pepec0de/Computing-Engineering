package amc.practica2;

import amc.practica2.interfaz.MainVentana;

public class Main {

	public static void main(String args[]) {		
		new MainVentana();
	}
}
