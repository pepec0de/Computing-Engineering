package practica8;

public interface Apilable {

	public boolean esMultiMeta();
	public boolean esMeta();
	public boolean esOperador();
}
